
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { hasValidSupabaseCredentials } from './lib/supabase.js'

// Display a warning if Supabase credentials are missing
if (!hasValidSupabaseCredentials()) {
  console.warn(
    'WARNING: Supabase credentials are missing. ' +
    'The app will work in demo mode but won\'t connect to a real database. ' +
    'Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY environment variables ' +
    'or connect to Supabase using the Lovable integration button in the top right corner.'
  );
}

createRoot(document.getElementById("root")).render(<App />);

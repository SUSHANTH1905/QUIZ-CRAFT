
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { supabase, isDemoMode } from '@/lib/supabase';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  useEffect(() => {
    // Check for authenticated user on component mount
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (session && session.user) {
          const { user: authUser } = session;
          
          // First update with basic user info to prevent null user issues
          setUser({
            id: authUser.id,
            email: authUser.email,
            name: authUser.email?.split('@')[0] || 'User',
            photoURL: ''
          });
          
          // Then fetch additional profile data
          setTimeout(() => {
            fetchUserProfile(authUser.id);
          }, 0);
        } else {
          setUser(null);
        }
        
        setIsLoading(false);
      }
    );
    
    // Separate function to fetch user profile to avoid auth deadlocks
    const fetchUserProfile = async (userId) => {
      try {
        const { data: profileData, error } = await supabase
          .from('users')
          .select('*')
          .eq('id', userId)
          .single();
        
        if (error) {
          console.warn('Error fetching user profile:', error);
          return; // We already set basic user info above
        }
        
        if (profileData) {
          setUser({
            id: profileData.id,
            email: profileData.email,
            name: profileData.name,
            contact: profileData.contact || '',
            photoURL: profileData.photo_url || ''
          });
        }
      } catch (err) {
        console.error('Error fetching user profile:', err);
      }
    };
    
    // Get initial session
    const fetchInitialSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.warn('Error getting session:', error);
          setIsLoading(false);
          return;
        }
        
        if (!session) {
          setIsLoading(false);
          return;
        }
        
        // The onAuthStateChange handler will set the user
      } catch (err) {
        console.error('Error in fetchInitialSession:', err);
        setIsLoading(false);
      }
    };
    
    fetchInitialSession();
    
    return () => {
      subscription?.unsubscribe();
    };
  }, []);

  const updateUserProfile = async (userData) => {
    if (!user) return;
    
    if (isDemoMode) {
      // In demo mode, simulate success but warn user
      toast({
        title: "Demo Mode: Profile updated",
        description: "This is running in demo mode. Connect to Supabase to enable real data storage.",
        variant: "warning"
      });
      
      // Update local user state anyway for better UX
      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      return;
    }
    
    try {
      // Update the users table
      const { error: updateError } = await supabase
        .from('users')
        .update({
          name: userData.name,
          email: userData.email,
          contact: userData.contact
        })
        .eq('id', user.id);
      
      if (updateError) {
        console.error('Error updating profile:', updateError);
        toast({
          title: "Profile update failed",
          description: updateError.message || "There was an error updating your profile.",
          variant: "destructive"
        });
        return;
      }
      
      // Update local user state
      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      });
    } catch (error) {
      console.error('Error in updateUserProfile:', error);
      toast({
        title: "Connection error",
        description: "Could not connect to the database. Please try again later.",
        variant: "destructive"
      });
    }
  };
  
  const updateUserPhoto = async (photoURL) => {
    if (!user) return;
    console.log("Updating photo URL:", photoURL);
    
    if (isDemoMode) {
      // In demo mode, simulate success but warn user
      toast({
        title: "Demo Mode: Photo updated",
        description: "This is running in demo mode. Connect to Supabase to enable real data storage.",
        variant: "warning"
      });
      
      // Update local user state anyway for better UX
      const updatedUser = { ...user, photoURL };
      setUser(updatedUser);
      return;
    }
    
    try {
      // Update the users table
      const { error: updateError } = await supabase
        .from('users')
        .update({
          photo_url: photoURL
        })
        .eq('id', user.id);
      
      if (updateError) {
        console.error('Error updating photo:', updateError);
        toast({
          title: "Photo update failed",
          description: updateError.message || "There was an error updating your profile photo.",
          variant: "destructive"
        });
        return;
      }
      
      // Update local user state
      const updatedUser = { ...user, photoURL };
      setUser(updatedUser);
      
      toast({
        title: "Photo updated",
        description: "Your profile photo has been updated successfully.",
      });
    } catch (error) {
      console.error('Error in updateUserPhoto:', error);
      toast({
        title: "Connection error",
        description: "Could not connect to the database. Please try again later.",
        variant: "destructive"
      });
    }
  };

  const login = async (email, password) => {
    try {
      setIsLoading(true);
      
      if (isDemoMode) {
        // In demo mode, create a simulated user for better UX
        setTimeout(() => {
          setUser({
            id: 'demo-user-id',
            email: email,
            name: email.split('@')[0] || 'Demo User',
            photoURL: ''
          });
          
          toast({
            title: "Demo Mode Login",
            description: "You're logged in with demo mode. Connect to Supabase for real authentication.",
            variant: "warning"
          });
        }, 1000);
        
        return true;
      }
      
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      
      if (error) {
        toast({
          title: "Login failed",
          description: error.message || "Invalid email or password.",
          variant: "destructive"
        });
        return false;
      }
      
      toast({
        title: "Login successful",
        description: `Welcome back!`,
      });
      
      return true;
    } catch (error) {
      console.error('Login error:', error);
      toast({
        title: "Connection error",
        description: "Could not connect to the authentication service. Please try again later.",
        variant: "destructive"
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name, email, password) => {
    try {
      setIsLoading(true);
      
      if (isDemoMode) {
        // In demo mode, create a simulated user for better UX
        setTimeout(() => {
          setUser({
            id: 'demo-user-id',
            email: email,
            name: name,
            photoURL: ''
          });
          
          toast({
            title: "Demo Mode Registration",
            description: "Account created in demo mode. Connect to Supabase for real authentication.",
            variant: "warning"
          });
        }, 1000);
        
        return true;
      }
      
      // Sign up the user with Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });
      
      if (error) {
        toast({
          title: "Registration failed",
          description: error.message || "Could not create your account.",
          variant: "destructive"
        });
        return false;
      }
      
      if (!data.user) {
        toast({
          title: "Registration issue",
          description: "No user was created. Please try again.",
          variant: "destructive"
        });
        return false;
      }
      
      // Create the user profile in our users table
      const { error: profileError } = await supabase
        .from('users')
        .insert({
          id: data.user.id,
          name,
          email,
          photo_url: ''
        });
      
      if (profileError) {
        console.error('Error creating profile:', profileError);
        // We don't return false here because auth was successful
      }
      
      toast({
        title: "Registration successful",
        description: `Welcome, ${name}!`,
      });
      
      return true;
    } catch (error) {
      console.error('Registration error:', error);
      toast({
        title: "Connection error",
        description: "Could not connect to the authentication service. Please try again later.",
        variant: "destructive"
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    if (isDemoMode) {
      // In demo mode, just clear the user
      setUser(null);
      toast({
        title: "Demo Mode Logout",
        description: "You've been logged out from demo mode.",
      });
      return;
    }
    
    try {
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        console.error('Error signing out:', error);
        toast({
          title: "Logout failed",
          description: error.message || "There was an error logging out. Please try again.",
          variant: "destructive"
        });
        return;
      }
      
      setUser(null);
      
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    } catch (error) {
      console.error('Logout error:', error);
      toast({
        title: "Connection error",
        description: "Could not connect to the authentication service. Please try again later.",
        variant: "destructive"
      });
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated: !!user, 
      isLoading,
      login, 
      register, 
      logout,
      updateUserProfile,
      updateUserPhoto,
      isDemoMode
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
};

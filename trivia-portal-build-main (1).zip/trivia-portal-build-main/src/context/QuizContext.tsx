
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Quiz, Question, QuizAttempt } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from './AuthContext';
import { supabase } from '@/lib/supabase';

interface QuizContextType {
  quizzes: Quiz[];
  userAttempts: QuizAttempt[];
  isLoading: boolean;
  createQuiz: (quiz: Omit<Quiz, 'id' | 'creatorId' | 'createdAt'>) => Promise<Quiz | null>;
  getQuiz: (id: string) => Promise<Quiz | null>;
  getUserQuizzes: () => Promise<Quiz[]>;
  submitQuizAttempt: (quizId: string, answers: QuizAttempt['answers']) => Promise<QuizAttempt | null>;
  getUserAttempts: () => Promise<QuizAttempt[]>;
  joinQuiz: (quizId: string) => Promise<boolean>;
}

const QuizContext = createContext<QuizContextType | undefined>(undefined);

export const QuizProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [userAttempts, setUserAttempts] = useState<QuizAttempt[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    // Fetch all quizzes when the component mounts
    const fetchQuizzes = async () => {
      try {
        setIsLoading(true);
        const { data, error } = await supabase
          .from('quizzes')
          .select(`
            *,
            questions:questions(*)
          `)
          .order('created_at', { ascending: false });
        
        if (error) {
          throw error;
        }
        
        // Transform from Supabase format to our app's format
        const transformedQuizzes = data.map((quiz: any) => ({
          id: quiz.id,
          title: quiz.title,
          description: quiz.description,
          creatorId: quiz.creator_id,
          createdAt: quiz.created_at,
          participants: quiz.participants,
          questions: quiz.questions.map((q: any) => ({
            id: q.id,
            text: q.text,
            type: q.type,
            options: q.options || [],
            correctAnswers: q.correct_answers || []
          }))
        }));
        
        setQuizzes(transformedQuizzes);
      } catch (error) {
        console.error('Error fetching quizzes:', error);
        toast({
          title: 'Error',
          description: 'Failed to load quizzes. Please try again later.',
          variant: 'destructive',
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchQuizzes();
  }, [toast]);

  const createQuiz = async (quizData: Omit<Quiz, 'id' | 'creatorId' | 'createdAt'>): Promise<Quiz | null> => {
    if (!user) {
      toast({
        title: "Authentication Error",
        description: "You must be logged in to create a quiz.",
        variant: "destructive"
      });
      return null;
    }

    try {
      // First insert the quiz
      const { data: newQuizData, error: quizError } = await supabase
        .from('quizzes')
        .insert({
          title: quizData.title,
          description: quizData.description,
          creator_id: user.id,
          participants: 0
        })
        .select()
        .single();
      
      if (quizError) throw quizError;
      
      // Then insert all questions related to this quiz
      const questions = quizData.questions?.map((q: Question) => ({
        quiz_id: newQuizData.id,
        text: q.text,
        type: q.type,
        options: q.options,
        correct_answers: q.correctAnswers
      })) || [];
      
      if (questions.length > 0) {
        const { error: questionsError } = await supabase
          .from('questions')
          .insert(questions);
        
        if (questionsError) throw questionsError;
      }
      
      // Fetch the quiz with its questions
      const { data: newQuiz, error: fetchError } = await supabase
        .from('quizzes')
        .select(`
          *,
          questions:questions(*)
        `)
        .eq('id', newQuizData.id)
        .single();
      
      if (fetchError) throw fetchError;
      
      // Transform to our app's format
      const transformedQuiz = {
        id: newQuiz.id,
        title: newQuiz.title,
        description: newQuiz.description,
        creatorId: newQuiz.creator_id,
        createdAt: newQuiz.created_at,
        participants: newQuiz.participants,
        questions: newQuiz.questions.map((q: any) => ({
          id: q.id,
          text: q.text,
          type: q.type,
          options: q.options || [],
          correctAnswers: q.correct_answers || []
        }))
      };
      
      // Update local state
      setQuizzes([transformedQuiz, ...quizzes]);
      
      toast({
        title: "Quiz Created",
        description: "Your quiz has been successfully created!"
      });
      
      return transformedQuiz;
    } catch (error) {
      console.error('Error creating quiz:', error);
      toast({
        title: "Error",
        description: "Failed to create quiz. Please try again.",
        variant: "destructive"
      });
      return null;
    }
  };

  const getQuiz = async (id: string): Promise<Quiz | null> => {
    try {
      const { data, error } = await supabase
        .from('quizzes')
        .select(`
          *,
          questions:questions(*)
        `)
        .eq('id', id)
        .single();
      
      if (error) throw error;
      
      return {
        id: data.id,
        title: data.title,
        description: data.description,
        creatorId: data.creator_id,
        createdAt: data.created_at,
        participants: data.participants,
        questions: data.questions.map((q: any) => ({
          id: q.id,
          text: q.text,
          type: q.type,
          options: q.options || [],
          correctAnswers: q.correct_answers || []
        }))
      };
    } catch (error) {
      console.error('Error fetching quiz:', error);
      return null;
    }
  };

  const getUserQuizzes = async (): Promise<Quiz[]> => {
    if (!user) return [];
    
    try {
      const { data, error } = await supabase
        .from('quizzes')
        .select(`
          *,
          questions:questions(*)
        `)
        .eq('creator_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      return data.map((quiz: any) => ({
        id: quiz.id,
        title: quiz.title,
        description: quiz.description,
        creatorId: quiz.creator_id,
        createdAt: quiz.created_at,
        participants: quiz.participants,
        questions: quiz.questions.map((q: any) => ({
          id: q.id,
          text: q.text,
          type: q.type,
          options: q.options || [],
          correctAnswers: q.correct_answers || []
        }))
      }));
    } catch (error) {
      console.error('Error fetching user quizzes:', error);
      return [];
    }
  };

  const submitQuizAttempt = async (quizId: string, answers: QuizAttempt['answers']): Promise<QuizAttempt | null> => {
    if (!user) {
      toast({
        title: "Authentication Error",
        description: "You must be logged in to submit a quiz.",
        variant: "destructive"
      });
      return null;
    }

    try {
      // Get the quiz to calculate score
      const quiz = await getQuiz(quizId);
      if (!quiz) {
        toast({
          title: "Quiz Error",
          description: "Quiz not found.",
          variant: "destructive"
        });
        return null;
      }

      // Calculate score
      let correctAnswers = 0;
      answers.forEach(answer => {
        const question = quiz.questions.find(q => q.id === answer.questionId);
        if (!question) return;

        if (question.type === 'multipleChoice' || question.type === 'checkboxes') {
          const isCorrect = answer.selectedOptions?.every(option => 
            question.correctAnswers?.includes(option)
          );
          if (isCorrect) correctAnswers++;
        }
      });

      const score = (correctAnswers / quiz.questions.length) * 100;

      // Create the attempt
      const { data: attemptData, error: attemptError } = await supabase
        .from('quiz_attempts')
        .insert({
          user_id: user.id,
          quiz_id: quizId,
          score,
        })
        .select()
        .single();
      
      if (attemptError) throw attemptError;
      
      // Insert all answers
      const answersToInsert = answers.map(answer => ({
        attempt_id: attemptData.id,
        question_id: answer.questionId,
        selected_options: answer.selectedOptions || [],
        text_answer: answer.textAnswer || ''
      }));
      
      const { error: answersError } = await supabase
        .from('answers')
        .insert(answersToInsert);
      
      if (answersError) throw answersError;
      
      // Update quiz participant count
      const { error: updateError } = await supabase.rpc(
        'increment_quiz_participants',
        { quiz_id: quizId }
      );
      
      if (updateError) console.error('Error updating participant count:', updateError);
      
      // Get the complete attempt with answers
      const { data: completeAttempt, error: fetchError } = await supabase
        .from('quiz_attempts')
        .select(`
          *,
          answers:answers(*)
        `)
        .eq('id', attemptData.id)
        .single();
      
      if (fetchError) throw fetchError;
      
      const transformedAttempt = {
        id: completeAttempt.id,
        userId: completeAttempt.user_id,
        quizId: completeAttempt.quiz_id,
        score: completeAttempt.score,
        completedAt: completeAttempt.completed_at,
        answers: completeAttempt.answers.map((a: any) => ({
          questionId: a.question_id,
          selectedOptions: a.selected_options || [],
          textAnswer: a.text_answer || ''
        }))
      };
      
      // Update local state
      setUserAttempts([transformedAttempt, ...userAttempts]);
      
      return transformedAttempt;
    } catch (error) {
      console.error('Error submitting quiz attempt:', error);
      toast({
        title: "Error",
        description: "Failed to submit quiz. Please try again.",
        variant: "destructive"
      });
      return null;
    }
  };

  const getUserAttempts = async (): Promise<QuizAttempt[]> => {
    if (!user) return [];
    
    try {
      const { data, error } = await supabase
        .from('quiz_attempts')
        .select(`
          *,
          answers:answers(*)
        `)
        .eq('user_id', user.id)
        .order('completed_at', { ascending: false });
      
      if (error) throw error;
      
      return data.map((attempt: any) => ({
        id: attempt.id,
        userId: attempt.user_id,
        quizId: attempt.quiz_id,
        score: attempt.score,
        completedAt: attempt.completed_at,
        answers: attempt.answers.map((a: any) => ({
          questionId: a.question_id,
          selectedOptions: a.selected_options || [],
          textAnswer: a.text_answer || ''
        }))
      }));
    } catch (error) {
      console.error('Error fetching user attempts:', error);
      return [];
    }
  };
  
  const joinQuiz = async (quizId: string): Promise<boolean> => {
    try {
      const quiz = await getQuiz(quizId);
      
      if (!quiz) {
        toast({
          title: "Quiz Error",
          description: "Quiz not found with the provided code.",
          variant: "destructive"
        });
        return false;
      }
      
      toast({
        title: "Quiz Joined",
        description: `You've joined ${quiz.title}.`
      });
      
      return true;
    } catch (error) {
      console.error('Error joining quiz:', error);
      toast({
        title: "Error",
        description: "Failed to join quiz. Please try again.",
        variant: "destructive"
      });
      return false;
    }
  };

  return (
    <QuizContext.Provider value={{
      quizzes,
      userAttempts,
      isLoading,
      createQuiz,
      getQuiz,
      getUserQuizzes,
      submitQuizAttempt,
      getUserAttempts,
      joinQuiz
    }}>
      {children}
    </QuizContext.Provider>
  );
};

export const useQuiz = (): QuizContextType => {
  const context = useContext(QuizContext);
  
  if (context === undefined) {
    throw new Error('useQuiz must be used within a QuizProvider');
  }
  
  return context;
};


export const UserType = {
  id: '',
  name: '',
  email: '',
  contact: '',
  photoURL: '',
  createdAt: ''
};

export const QuizType = {
  id: '',
  title: '',
  description: '',
  creatorId: '',
  createdAt: '',
  questions: [],
  participants: 0
};

export const QuestionType = {
  id: '',
  text: '',
  type: '', // 'multipleChoice' | 'checkboxes' | 'longAnswer'
  options: [],
  correctAnswers: []
};

export const QuizAttemptType = {
  id: '',
  userId: '',
  quizId: '',
  score: 0,
  completedAt: '',
  answers: []
};

export const AnswerType = {
  questionId: '',
  selectedOptions: [],
  textAnswer: ''
};

export const ActivityStatsType = {
  quizzesCreated: 0,
  quizzesAttempted: 0,
  dailyActivity: []
};

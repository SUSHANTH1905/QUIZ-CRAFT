import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuiz } from '@/context/QuizContext';
import { useAuth } from '@/context/AuthContext';
import { Answer, Quiz } from '@/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { CircleUser, Clock, Share2, Users } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';

export default function QuizPage() {
  const { quizId } = useParams();
  const { getQuiz, submitQuizAttempt } = useQuiz();
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [score, setScore] = useState<number | null>(null);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [joinCode, setJoinCode] = useState('');
  const [joinDialogOpen, setJoinDialogOpen] = useState(false);
  
  useEffect(() => {
    const fetchQuiz = async () => {
      if (quizId) {
        const fetchedQuiz = await getQuiz(quizId);
        setQuiz(fetchedQuiz);
        setLoading(false);
        
        if (fetchedQuiz) {
          document.title = `${fetchedQuiz.title} | QuizCraft`;
          
          // Initialize answers array for all questions with empty answers
          const initialAnswers = fetchedQuiz.questions.map(question => ({
            questionId: question.id,
            selectedOptions: []
          }));
          
          setAnswers(initialAnswers);
        }
      }
    };
    
    fetchQuiz();
  }, [quizId, getQuiz]);
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (!loading && !quiz) {
      toast({
        title: "Quiz not found",
        description: "The quiz you're looking for doesn't exist.",
        variant: "destructive"
      });
      navigate('/play-quiz');
      return;
    }
  }, [quiz, isAuthenticated, navigate, loading, toast]);
  
  if (loading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }
  
  if (!quiz) {
    return null;
  }
  
  const currentQuestion = quiz?.questions[currentQuestionIndex];
  
  const handleOptionChange = (option: string, isChecked: boolean) => {
    if (!currentQuestion) return;
    
    setAnswers(prevAnswers => {
      return prevAnswers.map((answer, index) => {
        if (index === currentQuestionIndex) {
          let updatedOptions = [...(answer.selectedOptions || [])];
          
          if (currentQuestion.type === 'multipleChoice') {
            // For multiple choice, replace the entire selection
            updatedOptions = isChecked ? [option] : [];
          } else {
            // For checkboxes, add or remove the option
            if (isChecked) {
              updatedOptions.push(option);
            } else {
              updatedOptions = updatedOptions.filter(opt => opt !== option);
            }
          }
          
          return { ...answer, selectedOptions: updatedOptions };
        }
        return answer;
      });
    });
  };
  
  const handleTextAnswerChange = (text: string) => {
    if (!currentQuestion) return;
    
    setAnswers(prevAnswers => {
      return prevAnswers.map((answer, index) => {
        if (index === currentQuestionIndex) {
          return { ...answer, textAnswer: text };
        }
        return answer;
      });
    });
  };
  
  const goToNextQuestion = () => {
    if (currentQuestionIndex < (quiz?.questions.length || 0) - 1) {
      setCurrentQuestionIndex(prevIndex => prevIndex + 1);
    } else {
      // Complete quiz
      completeQuiz();
    }
  };
  
  const goToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prevIndex => prevIndex - 1);
    }
  };
  
  const completeQuiz = async () => {
    if (!quiz) return;
    
    try {
      const attempt = await submitQuizAttempt(quiz.id, answers);
      if (attempt) {
        setScore(attempt.score);
        setQuizCompleted(true);
        
        toast({
          title: "Quiz Completed",
          description: `Your score: ${attempt.score.toFixed(1)}%`
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit quiz. Please try again.",
        variant: "destructive"
      });
    }
  };
  
  const copyShareLink = () => {
    const shareUrl = `${window.location.origin}/play-quiz/${quiz?.id}`;
    navigator.clipboard.writeText(shareUrl);
    
    toast({
      title: "Link Copied",
      description: "Share this link with friends to invite them to take this quiz!"
    });
    
    setShareDialogOpen(false);
  };
  
  return (
    <div className="container py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {!quizCompleted ? (
          <Card className="shadow-lg">
            <CardHeader className="bg-gold-gradient text-white">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-2xl">{quiz.title}</CardTitle>
                  {quiz.description && (
                    <CardDescription className="text-white/80 mt-2">{quiz.description}</CardDescription>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-white/20 hover:bg-white/30">
                    <Users size={14} className="mr-1" />
                    {quiz.participants || 0}
                  </Badge>
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    className="text-white hover:text-white/80 hover:bg-white/20"
                    onClick={() => setShareDialogOpen(true)}
                  >
                    <Share2 size={18} />
                  </Button>
                </div>
              </div>
              <div className="flex items-center gap-2 mt-4 text-sm text-white/80">
                <CircleUser size={14} />
                <span>Created by {user?.id === quiz.creatorId ? 'you' : 'someone else'}</span>
                <span className="mx-2">•</span>
                <Clock size={14} />
                <span>
                  {new Date(quiz.createdAt).toLocaleDateString()}
                </span>
              </div>
            </CardHeader>
            
            <CardContent className="pt-6 pb-4">
              <div className="flex justify-between items-center mb-6">
                <span className="text-sm text-muted-foreground">
                  Question {currentQuestionIndex + 1} of {quiz.questions.length}
                </span>
                <span className="text-sm font-medium">
                  {Math.round(((currentQuestionIndex + 1) / quiz.questions.length) * 100)}% Complete
                </span>
              </div>
              
              {currentQuestion && (
                <div className="space-y-6">
                  <h3 className="text-xl font-medium">{currentQuestion.text}</h3>
                  
                  {currentQuestion.type === 'multipleChoice' && (
                    <RadioGroup 
                      value={answers[currentQuestionIndex]?.selectedOptions?.[0] || ''}
                      onValueChange={(value) => handleOptionChange(value, true)}
                      className="space-y-3"
                    >
                      {currentQuestion.options?.map(option => (
                        <div key={option} className="flex items-center space-x-2 p-3 rounded-md border">
                          <RadioGroupItem value={option} id={`option-${option}`} />
                          <Label htmlFor={`option-${option}`} className="flex-grow cursor-pointer">
                            {option}
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  )}
                  
                  {currentQuestion.type === 'checkboxes' && (
                    <div className="space-y-3">
                      {currentQuestion.options?.map(option => (
                        <div key={option} className="flex items-center space-x-2 p-3 rounded-md border">
                          <Checkbox 
                            id={`option-${option}`}
                            checked={answers[currentQuestionIndex]?.selectedOptions?.includes(option) || false}
                            onCheckedChange={(checked) => handleOptionChange(option, !!checked)}
                          />
                          <Label htmlFor={`option-${option}`} className="flex-grow cursor-pointer">
                            {option}
                          </Label>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {currentQuestion.type === 'longAnswer' && (
                    <Textarea 
                      value={answers[currentQuestionIndex]?.textAnswer || ''}
                      onChange={(e) => handleTextAnswerChange(e.target.value)}
                      placeholder="Type your answer here..."
                      className="h-32"
                    />
                  )}
                </div>
              )}
            </CardContent>
            
            <CardFooter className="flex justify-between pt-4">
              <Button
                variant="outline"
                onClick={goToPreviousQuestion}
                disabled={currentQuestionIndex === 0}
              >
                Previous
              </Button>
              
              <Button
                className="bg-gold-gradient hover:bg-gold-gradient-hover"
                onClick={goToNextQuestion}
              >
                {currentQuestionIndex === quiz.questions.length - 1 ? 'Submit Quiz' : 'Next'}
              </Button>
            </CardFooter>
          </Card>
        ) : (
          <Card className="shadow-lg">
            <CardHeader className="bg-gold-gradient text-white text-center">
              <CardTitle className="text-2xl">Quiz Completed!</CardTitle>
              <CardDescription className="text-white/80">
                You've completed {quiz.title}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-6 text-center">
              <div className="mb-8">
                <div className="text-6xl font-bold gold-gradient-text mb-2">
                  {score !== null ? `${score.toFixed(1)}%` : '0%'}
                </div>
                <p className="text-muted-foreground">Your score</p>
              </div>
              
              <div className="flex flex-col gap-4 max-w-md mx-auto">
                <Button 
                  className="bg-gold-gradient hover:bg-gold-gradient-hover"
                  onClick={() => setShareDialogOpen(true)}
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Share Quiz
                </Button>
                
                <Button 
                  variant="outline"
                  onClick={() => navigate('/play-quiz')}
                >
                  Take Another Quiz
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
      
      {/* Share Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share This Quiz</DialogTitle>
            <DialogDescription>
              Copy the link below to share this quiz with friends.
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center gap-2 mt-4">
            <Input 
              readOnly 
              value={`${window.location.origin}/play-quiz/${quiz.id}`} 
              onClick={(e) => (e.target as HTMLInputElement).select()}
            />
            <Button onClick={copyShareLink}>Copy</Button>
          </div>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setShareDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Join Dialog */}
      <Dialog open={joinDialogOpen} onOpenChange={setJoinDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Join a Quiz</DialogTitle>
            <DialogDescription>
              Enter the quiz code shared with you to join.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-4">
            <Input 
              placeholder="Enter quiz code" 
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value)}
            />
            <Button 
              onClick={() => {
                if (joinCode.trim()) {
                  navigate(`/play-quiz/${joinCode}`);
                  setJoinDialogOpen(false);
                }
              }}
            >
              Join Quiz
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

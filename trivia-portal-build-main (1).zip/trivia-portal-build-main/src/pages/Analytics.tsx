
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/context/AuthContext';
import { useQuiz } from '@/context/QuizContext';
import { Quiz } from '@/types';

const COLORS = ['#B8860B', '#D4AF37', '#8B4513', '#32281E'];

export default function Analytics() {
  const { isAuthenticated } = useAuth();
  const { userAttempts, getUserQuizzes } = useQuiz();
  const navigate = useNavigate();
  const [userQuizzes, setUserQuizzes] = useState<Quiz[]>([]);

  useEffect(() => {
    document.title = 'Analytics | QuizCraft';
    
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  // Fetch user quizzes when component mounts
  useEffect(() => {
    const fetchUserQuizzes = async () => {
      const quizzes = await getUserQuizzes();
      setUserQuizzes(quizzes);
    };
    fetchUserQuizzes();
  }, [getUserQuizzes]);
  
  // Create data for charts
  const quizActivityData = [
    { name: 'Week 1', quizzesCreated: 2, quizzesAttempted: 5 },
    { name: 'Week 2', quizzesCreated: 1, quizzesAttempted: 7 },
    { name: 'Week 3', quizzesCreated: 3, quizzesAttempted: 6 },
    { name: 'Week 4', quizzesCreated: 2, quizzesAttempted: 4 },
  ];
  
  const quizTypeData = [
    { name: 'Multiple Choice', value: 65 },
    { name: 'Checkboxes', value: 25 },
    { name: 'Long Answer', value: 10 },
  ];

  return (
    <div className="container py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">
          <span className="gold-gradient-text">DASHBOARD</span>
        </h1>
        <p className="text-muted-foreground mt-2">View your quiz stats and analytics</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle>Quiz Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Number of Quizzes Created:</span>
                <span className="font-medium text-quiz-primary">{userQuizzes.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Number of Quizzes Attempted:</span>
                <span className="font-medium text-quiz-primary">{userAttempts.length}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1 md:col-span-2 bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle>Quiz Activity Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={quizActivityData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="quizzesCreated" fill="#B8860B" />
                  <Bar dataKey="quizzesAttempted" fill="#D4AF37" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/80 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle>Question Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={quizTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {quizTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

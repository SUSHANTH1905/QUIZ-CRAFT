
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { Question } from '@/types';
import { useQuiz } from '@/context/QuizContext';
import { useAuth } from '@/context/AuthContext';
import { QuestionForm } from '@/components/quiz/QuestionForm';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { PlusCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';
import { isDemoMode } from '@/lib/supabase';

const quizSchema = z.object({
  title: z.string().min(1, 'Quiz title is required'),
  description: z.string().optional(),
});

type QuizFormValues = z.infer<typeof quizSchema>;

export default function CreateQuiz() {
  const { isAuthenticated } = useAuth();
  const { createQuiz } = useQuiz();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: uuidv4(),
      text: '',
      type: 'multipleChoice',
      options: [],
      correctAnswers: [],
    },
  ]);

  useEffect(() => {
    document.title = 'Create Quiz | QuizCraft';
    
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  const form = useForm<QuizFormValues>({
    resolver: zodResolver(quizSchema),
    defaultValues: {
      title: '',
      description: '',
    },
  });

  const addQuestion = () => {
    const newQuestion: Question = {
      id: uuidv4(),
      text: '',
      type: 'multipleChoice',
      options: [],
      correctAnswers: [],
    };
    
    setQuestions([...questions, newQuestion]);
  };

  const updateQuestion = (id: string, updatedQuestion: Question) => {
    setQuestions(
      questions.map((q) => (q.id === id ? updatedQuestion : q))
    );
  };

  const removeQuestion = (id: string) => {
    if (questions.length <= 1) {
      toast({
        title: "Cannot remove",
        description: "A quiz must have at least one question.",
        variant: "destructive"
      });
      return;
    }
    
    setQuestions(questions.filter((q) => q.id !== id));
  };

  const onSubmit = async (values: QuizFormValues) => {
    // Validate questions
    const invalidQuestions = questions.filter(q => {
      if (!q.text.trim()) return true;
      
      if (q.type === 'multipleChoice' || q.type === 'checkboxes') {
        return !q.options?.length || q.options.length < 2;
      }
      
      return false;
    });
    
    if (invalidQuestions.length > 0) {
      toast({
        title: "Invalid Questions",
        description: "Please ensure all questions have text and at least two options.",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      const newQuiz = await createQuiz({
        title: values.title,
        description: values.description,
        questions
      });
      
      if (newQuiz) {
        toast({
          title: "Quiz Created",
          description: isDemoMode ? 
            "Quiz created in demo mode. Connect to Supabase to save permanently." : 
            "Your quiz has been successfully created!",
          variant: "default"
        });
        navigate(`/play-quiz/${newQuiz.id}`);
      } else {
        throw new Error("Failed to create quiz");
      }
    } catch (error) {
      console.error("Quiz creation error:", error);
      toast({
        title: "Error",
        description: isDemoMode ? 
          "Failed to create quiz in demo mode. Please try again or connect to Supabase." : 
          "Failed to create quiz. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold gold-gradient-text">BUILD A QUIZ</h1>
          <p className="text-muted-foreground mt-2">
            Design questions, set answer choices, and customize quiz settings
          </p>
        </div>
        
        {isDemoMode && (
          <Alert variant="warning" className="mb-6">
            <AlertTriangle className="h-5 w-5" />
            <AlertDescription>
              Running in demo mode. Quizzes created will be stored temporarily.
              Connect to Supabase to save quizzes permanently.
            </AlertDescription>
          </Alert>
        )}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <div className="space-y-4 p-6 rounded-lg bg-white/60 backdrop-blur-sm">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quiz Title</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter quiz title" 
                        {...field}
                        className="text-lg font-medium"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Add a description for your quiz"
                        {...field}
                        rows={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">Questions</h2>
              </div>

              {questions.map((question, index) => (
                <QuestionForm
                  key={question.id}
                  question={question}
                  onChange={(updatedQuestion) => updateQuestion(question.id, updatedQuestion)}
                  onDelete={() => removeQuestion(question.id)}
                />
              ))}

              <Button
                type="button"
                onClick={addQuestion}
                variant="outline"
                className="w-full py-6 border-dashed border-2 hover:bg-muted/50"
              >
                <PlusCircle className="mr-2" size={20} />
                Add Question
              </Button>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                type="submit"
                size="lg"
                className="bg-gold-gradient hover:bg-gold-gradient-hover"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Creating..." : "Create Quiz"}
              </Button>
              
              <Button
                type="button"
                variant="outline"
                size="lg"
                onClick={() => navigate('/dashboard')}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}


import { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { SignupForm } from '@/components/auth/SignupForm';
import { useAuth } from '@/context/AuthContext';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';

export default function Signup() {
  const { isAuthenticated, isDemoMode } = useAuth();

  useEffect(() => {
    document.title = 'Sign Up | QuizCraft';
  }, []);

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center p-4 blurry-bg custom-bg-pattern"
      style={{
        background: 'linear-gradient(90deg, #32281E 0%, #B8860B 50%, #D4AF37 100%)'
      }}
    >
      <div className="w-full max-w-md">
        {isDemoMode && (
          <Alert variant="warning" className="mb-4">
            <AlertTriangle className="h-5 w-5" />
            <AlertDescription>
              Running in demo mode. Connect to Supabase to enable real user registration.
            </AlertDescription>
          </Alert>
        )}
        <SignupForm />
      </div>
    </div>
  );
}

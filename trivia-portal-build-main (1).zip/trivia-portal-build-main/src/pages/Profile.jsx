
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useQuiz } from '@/context/QuizContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { QuizCard } from '@/components/quiz/QuizCard';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ProfileEditForm } from '@/components/profile/ProfileEditForm';
import { Camera } from 'lucide-react';

const PhotoUploader = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const { updateUserPhoto } = useAuth();
  
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      const fileUrl = URL.createObjectURL(file);
      setPreviewUrl(fileUrl);
    }
  };
  
  const handleUpload = () => {
    if (selectedFile) {
      // In a real app, this would upload the file to storage
      // For now, just update with the URL
      updateUserPhoto(previewUrl);
    }
  };
  
  return (
    <div className="space-y-4">
      {previewUrl && (
        <div className="flex justify-center">
          <Avatar className="w-32 h-32">
            <AvatarImage src={previewUrl} alt="Preview" />
            <AvatarFallback>Preview</AvatarFallback>
          </Avatar>
        </div>
      )}
      
      <div className="flex flex-col items-center gap-4">
        <label className="cursor-pointer">
          <div className="px-4 py-2 bg-muted hover:bg-muted/80 rounded-md text-center">
            {previewUrl ? 'Change Photo' : 'Select Photo'}
          </div>
          <input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            onChange={handleFileChange}
          />
        </label>
        
        {previewUrl && (
          <Button onClick={handleUpload}>
            Save New Photo
          </Button>
        )}
      </div>
    </div>
  );
};

export default function Profile() {
  const { user, isAuthenticated, updateUserProfile } = useAuth();
  const { getUserQuizzes } = useQuiz();
  const navigate = useNavigate();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [defaultPhoto] = useState('/lovable-uploads/e380d9d9-1277-4c9f-8386-4d2551a54441.png');

  useEffect(() => {
    document.title = 'My Profile | QuizCraft';
    
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  const userQuizzes = getUserQuizzes();

  const handleProfileUpdate = (updatedProfile) => {
    updateUserProfile(updatedProfile);
    setIsEditDialogOpen(false);
  };

  const getAvatarImage = () => {
    if (user?.photoURL) {
      return user.photoURL;
    }
    return defaultPhoto;
  };

  return (
    <div className="container py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold gold-gradient-text mb-8">MY PROFILE</h1>
        
        <div className="grid gap-8">
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
                <div className="relative">
                  <Avatar className="w-32 h-32">
                    <AvatarImage src={getAvatarImage()} alt={user?.name} />
                    <AvatarFallback className="bg-gold-gradient text-white text-4xl">
                      {user?.name?.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        variant="secondary" 
                        size="icon"
                        className="absolute bottom-0 right-0 rounded-full"
                      >
                        <Camera className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Change Profile Photo</DialogTitle>
                        <DialogDescription>
                          Upload a new profile photo
                        </DialogDescription>
                      </DialogHeader>
                      <PhotoUploader />
                    </DialogContent>
                  </Dialog>
                </div>
                
                <div className="space-y-4 text-center md:text-left">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-medium text-muted-foreground">NAME:</p>
                      <h2 className="text-xl font-bold">{user?.name}</h2>
                    </div>
                    
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-medium text-muted-foreground">EMAIL:</p>
                      <p>{user?.email}</p>
                    </div>
                    
                    {user?.contact && (
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-medium text-muted-foreground">CONTACT:</p>
                        <p>{user?.contact}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-4 flex-wrap justify-center md:justify-start">
                    <div className="bg-muted px-4 py-2 rounded-md">
                      <span className="block text-2xl font-bold text-quiz-primary">
                        {userQuizzes.length}
                      </span>
                      <span className="text-xs text-muted-foreground">Quizzes Created</span>
                    </div>
                  </div>
                  
                  <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline">Edit Profile</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Edit Profile</DialogTitle>
                        <DialogDescription>
                          Update your profile information
                        </DialogDescription>
                      </DialogHeader>
                      <ProfileEditForm 
                        user={user} 
                        onSubmit={handleProfileUpdate} 
                        onCancel={() => setIsEditDialogOpen(false)}
                      />
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Created Quizzes</CardTitle>
            </CardHeader>
            <CardContent>
              {userQuizzes.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {userQuizzes.map((quiz) => (
                    <QuizCard key={quiz.id} quiz={quiz} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <p className="text-muted-foreground">You haven&apos;t created any quizzes yet.</p>
                  <button
                    onClick={() => navigate('/create-quiz')}
                    className="mt-4 px-4 py-2 bg-quiz-primary text-white rounded-md hover:bg-quiz-secondary transition-colors"
                  >
                    Create Your First Quiz
                  </button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}


import { useEffect } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { HelpCircle, BookOpen, Play, Award, Users, MessageSquare } from 'lucide-react';

export default function Help() {
  useEffect(() => {
    document.title = 'Help | QuizCraft';
  }, []);

  return (
    <div className="container py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center mb-8">
          <HelpCircle className="h-8 w-8 mr-2 text-quiz-primary" />
          <h1 className="text-3xl font-bold gold-gradient-text">HELP</h1>
        </div>
        
        <Card className="bg-white/80 backdrop-blur-sm mb-8">
          <CardHeader>
            <CardTitle>Getting Started</CardTitle>
            <CardDescription>
              Learn the basics of QuizCraft and how to use our platform
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger className="flex items-center">
                  <BookOpen className="h-5 w-5 mr-2 text-quiz-primary" />
                  How to Create a Quiz
                </AccordionTrigger>
                <AccordionContent>
                  <ol className="list-decimal pl-5 space-y-2">
                    <li>Navigate to the "Build a Quiz" page from the dashboard or navigation menu</li>
                    <li>Enter a title and optional description for your quiz</li>
                    <li>Add questions by clicking the "Add Question" button</li>
                    <li>For each question, enter the question text and select a question type</li>
                    <li>Add answer options and mark the correct answer(s)</li>
                    <li>Click "Create Quiz" when you're done</li>
                  </ol>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-2">
                <AccordionTrigger className="flex items-center">
                  <Play className="h-5 w-5 mr-2 text-quiz-primary" />
                  How to Play a Quiz
                </AccordionTrigger>
                <AccordionContent>
                  <ol className="list-decimal pl-5 space-y-2">
                    <li>Go to the "Play a Quiz" page from the dashboard or navigation menu</li>
                    <li>Browse available quizzes or search for a specific quiz</li>
                    <li>Click on a quiz to view details</li>
                    <li>Click "Start Quiz" to begin answering questions</li>
                    <li>Select your answers for each question and proceed</li>
                    <li>Submit your answers to see your score and feedback</li>
                  </ol>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-3">
                <AccordionTrigger className="flex items-center">
                  <Users className="h-5 w-5 mr-2 text-quiz-primary" />
                  Sharing Quizzes with Others
                </AccordionTrigger>
                <AccordionContent>
                  <p className="mb-2">There are several ways to share your quizzes with others:</p>
                  <ol className="list-decimal pl-5 space-y-2">
                    <li>After creating a quiz, you'll receive a shareable link</li>
                    <li>Copy this link and share it via email, messaging apps, or social media</li>
                    <li>Anyone with the link can access and take your quiz</li>
                    <li>You can also view participant results in your dashboard</li>
                  </ol>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
        
        <Card className="bg-white/80 backdrop-blur-sm mb-8">
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
            <CardDescription>
              Common questions and answers about using QuizCraft
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="faq-1">
                <AccordionTrigger>Can I edit my quiz after publishing?</AccordionTrigger>
                <AccordionContent>
                  Yes, you can edit your quiz after publishing. Navigate to your profile, find the quiz you want to modify, and click the "Edit" button. Make your changes and save to update the quiz.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="faq-2">
                <AccordionTrigger>How are quiz scores calculated?</AccordionTrigger>
                <AccordionContent>
                  Quiz scores are calculated based on the number of correct answers divided by the total number of questions, then multiplied by 100 to get a percentage. Each question is weighted equally unless specified otherwise.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="faq-3">
                <AccordionTrigger>Can I use images in my quizzes?</AccordionTrigger>
                <AccordionContent>
                  Currently, the ability to include images in quizzes is planned for a future update. We're working on adding this feature to enhance the quiz creation experience.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="faq-4">
                <AccordionTrigger>Is there a limit to how many quizzes I can create?</AccordionTrigger>
                <AccordionContent>
                  No, there's no limit to the number of quizzes you can create with a standard account. Create as many quizzes as you'd like!
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="faq-5">
                <AccordionTrigger>How do I delete my account?</AccordionTrigger>
                <AccordionContent>
                  To delete your account, go to the Settings page and scroll down to the bottom where you'll find the "Delete Account" button. Clicking this will prompt you to confirm your decision. Please note that account deletion is permanent and will remove all your quizzes and data.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
        
        <Card className="bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <MessageSquare className="h-5 w-5 mr-2 text-quiz-primary" />
              Contact Support
            </CardTitle>
            <CardDescription>
              Need more help? Reach out to our support team
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4">If you couldn't find answers to your questions in our help section, please contact our support team.</p>
            <div className="space-y-2">
              <p>
                <span className="font-medium">Email:</span>{" "}
                <a href="mailto:support@quizcraft.example" className="text-quiz-primary hover:underline">
                  support@quizcraft.example
                </a>
              </p>
              <p>
                <span className="font-medium">Response Time:</span>{" "}
                <span>Usually within 24-48 hours</span>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

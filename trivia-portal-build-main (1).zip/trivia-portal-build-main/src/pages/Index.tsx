
import { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

// Redirect to login page or dashboard based on authentication status
const Index = () => {
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    document.title = 'QuizCraft';
  }, []);

  return isAuthenticated ? <Navigate to="/dashboard" /> : <Navigate to="/login" />;
};

export default Index;


import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Settings as SettingsIcon, User, Bell, Shield, HelpCircle } from 'lucide-react';

export default function Settings() {
  const { isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    document.title = 'Settings | QuizCraft';
    
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  return (
    <div className="container py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center mb-8">
          <SettingsIcon className="h-8 w-8 mr-2 text-quiz-primary" />
          <h1 className="text-3xl font-bold gold-gradient-text">SETTINGS</h1>
        </div>
        
        <Card className="bg-white/80 backdrop-blur-sm mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center">
              <div className="bg-gold-gradient text-white p-1 rounded mr-2">
                <User size={16} />
              </div>
              Preferences
            </CardTitle>
            <CardDescription>
              Customize your QuizCraft experience
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="theme-mode">Dark Mode</Label>
                  <p className="text-sm text-muted-foreground">
                    Toggle between light and dark theme
                  </p>
                </div>
                <Switch id="theme-mode" />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="sound-effects">Sound Effects</Label>
                  <p className="text-sm text-muted-foreground">
                    Enable sound effects during quizzes
                  </p>
                </div>
                <Switch id="sound-effects" defaultChecked />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/80 backdrop-blur-sm mb-6">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center">
              <div className="bg-gold-gradient text-white p-1 rounded mr-2">
                <Bell size={16} />
              </div>
              Notifications
            </CardTitle>
            <CardDescription>
              Manage your notification preferences
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="email-notifications">Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive quiz invitations and updates via email
                  </p>
                </div>
                <Switch id="email-notifications" defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="result-notifications">Quiz Results</Label>
                  <p className="text-sm text-muted-foreground">
                    Get notified when someone completes your quiz
                  </p>
                </div>
                <Switch id="result-notifications" defaultChecked />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/80 backdrop-blur-sm mb-8">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center">
              <div className="bg-gold-gradient text-white p-1 rounded mr-2">
                <HelpCircle size={16} />
              </div>
              Help & Support
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>How do I create a quiz?</AccordionTrigger>
                <AccordionContent>
                  To create a quiz, navigate to the "Create Quiz" page from the dashboard or navigation menu. Fill in your quiz title, add questions, set answer options, and click "Create Quiz" to publish it.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>How do I share my quiz with others?</AccordionTrigger>
                <AccordionContent>
                  After creating a quiz, you'll receive a shareable link that you can send to others via email, messaging apps, or social media. Recipients can use this link to access and take your quiz.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>Can I edit my quiz after publishing?</AccordionTrigger>
                <AccordionContent>
                  Yes, you can edit your quiz after publishing. Go to your profile, find the quiz you want to modify, and click the "Edit" button. Make your changes and save to update the quiz.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <Button 
            variant="outline" 
            className="border-destructive text-destructive hover:bg-destructive/10"
            onClick={logout}
          >
            Logout
          </Button>
          
          <Button 
            variant="outline" 
            className="border-destructive text-destructive hover:bg-destructive/10"
          >
            Delete Account
          </Button>
        </div>
      </div>
    </div>
  );
}

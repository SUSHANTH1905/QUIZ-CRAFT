import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/context/AuthContext';
import { useQuiz } from '@/context/QuizContext';
import { QuizCard } from '@/components/quiz/QuizCard';
import { BookOpen, Play, Users, Share2 } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Quiz } from '@/types';

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const { quizzes, userAttempts, getUserQuizzes } = useQuiz();
  const navigate = useNavigate();
  const [joinDialogOpen, setJoinDialogOpen] = useState(false);
  const [joinCode, setJoinCode] = useState('');
  const [userQuizzes, setUserQuizzes] = useState<Quiz[]>([]);

  useEffect(() => {
    document.title = 'Dashboard | QuizCraft';
  }, []);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  // Fetch user quizzes when component mounts
  useEffect(() => {
    const fetchUserQuizzes = async () => {
      const quizzes = await getUserQuizzes();
      setUserQuizzes(quizzes);
    };
    fetchUserQuizzes();
  }, [getUserQuizzes]);
  
  const handleJoinQuiz = () => {
    if (joinCode.trim()) {
      navigate(`/play-quiz/${joinCode}`);
      setJoinDialogOpen(false);
      setJoinCode('');
    }
  };

  return (
    <div className="container py-8 px-4 md:px-8">
      <div className="flex flex-col gap-2 mb-8">
        <h1 className="text-2xl md:text-3xl font-bold flex items-center">
          <span className="text-xl md:text-2xl font-normal mr-2">WELCOME!</span>
          <span className="gold-gradient-text">{user?.name}</span>
        </h1>
        <p className="text-muted-foreground">Your quiz creation and participation hub</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="col-span-full md:col-span-1 bg-white/80 backdrop-blur-sm hover:shadow-md transition-all">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">
              <span className="gold-gradient-text">QUIZ</span> CRAFT
            </CardTitle>
            <CardDescription>Create, play, and engage with quizzes</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <Button 
                onClick={() => navigate('/create-quiz')}
                className="flex-1 bg-gold-gradient hover:bg-gold-gradient-hover"
              >
                <BookOpen className="mr-2 h-4 w-4" />
                Build a Quiz
              </Button>
              <Button 
                onClick={() => navigate('/play-quiz')}
                variant="outline"
                className="flex-1 border-quiz-primary text-quiz-primary hover:bg-quiz-primary/10"
              >
                <Play className="mr-2 h-4 w-4" />
                Play a Quiz
              </Button>
            </div>
            
            <Button 
              onClick={() => setJoinDialogOpen(true)}
              variant="secondary"
              className="w-full"
            >
              <Share2 className="mr-2 h-4 w-4" />
              Join Quiz with Code
            </Button>
            
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="flex flex-col items-center p-4 bg-muted rounded-md">
                <span className="text-xl font-bold text-quiz-primary">{userQuizzes.length}</span>
                <span className="text-sm text-muted-foreground">Quizzes Created</span>
              </div>
              <div className="flex flex-col items-center p-4 bg-muted rounded-md">
                <span className="text-xl font-bold text-quiz-primary">{userAttempts.length}</span>
                <span className="text-sm text-muted-foreground">Quizzes Attempted</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Quizzes Card */}
        <Card className="col-span-full md:col-span-2 bg-white/80 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-xl">Recent Quizzes</CardTitle>
              <CardDescription>Join others in these popular quizzes</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/play-quiz')}>
              View All
            </Button>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {quizzes.slice(0, 2).map((quiz) => (
                <QuizCard key={quiz.id} quiz={quiz} />
              ))}
            </div>
          </CardContent>
        </Card>

        {userQuizzes.length > 0 && (
          <Card className="col-span-full bg-white/80 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle className="text-xl">Your Created Quizzes</CardTitle>
                <CardDescription>Manage and track your quizzes</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => navigate('/profile')}>
                View All
              </Button>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {userQuizzes.slice(0, 3).map((quiz) => (
                  <QuizCard key={quiz.id} quiz={quiz} />
                ))}
              </div>
            </CardContent>
          </Card>
        )}
        
        {userAttempts.length > 0 && (
          <Card className="col-span-full bg-white/80 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle className="text-xl">Your Quiz Attempts</CardTitle>
                <CardDescription>View your scores and performance</CardDescription>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {userAttempts.slice(0, 3).map((attempt) => {
                  const quiz = quizzes.find(q => q.id === attempt.quizId);
                  if (!quiz) return null;
                  
                  return (
                    <Card key={attempt.id} className="hover:shadow-md transition-all">
                      <CardHeader className="p-4">
                        <CardTitle className="text-base">{quiz.title}</CardTitle>
                      </CardHeader>
                      <CardContent className="p-4 pt-0">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">
                            Completed on {new Date(attempt.completedAt).toLocaleDateString()}
                          </span>
                          <span className="text-lg font-bold gold-gradient-text">
                            {attempt.score.toFixed(1)}%
                          </span>
                        </div>
                        <Button 
                          variant="link" 
                          className="p-0 h-auto mt-2 text-quiz-primary"
                          onClick={() => navigate(`/play-quiz/${quiz.id}`)}
                        >
                          Take Again
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
      
      {/* Join Quiz Dialog */}
      <Dialog open={joinDialogOpen} onOpenChange={setJoinDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Join a Quiz</DialogTitle>
            <DialogDescription>
              Enter the quiz code or ID shared with you to join.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-4">
            <Input 
              placeholder="Enter quiz code" 
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value)}
            />
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setJoinDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button onClick={handleJoinQuiz}>
                Join Quiz
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}


import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { User, Settings, Home, PieChart, BookOpen, HelpCircle, Menu, X } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const NavLinks = [
  { name: 'Home', path: '/dashboard', icon: <Home size={20} /> },
  { name: 'Build a Quiz', path: '/create-quiz', icon: <BookOpen size={20} /> },
  { name: 'Play a Quiz', path: '/play-quiz', icon: <BookOpen size={20} /> },
  { name: 'Dashboard', path: '/analytics', icon: <PieChart size={20} /> },
  { name: 'Settings', path: '/settings', icon: <Settings size={20} /> },
  { name: 'Help', path: '/help', icon: <HelpCircle size={20} /> },
];

export function Navbar() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => setMobileMenuOpen(!mobileMenuOpen);

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link to="/dashboard" className="flex items-center gap-2">
              <div className="gold-gradient-text font-bold text-xl">QuizCraft</div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex lg:items-center lg:gap-6">
            {NavLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={cn(
                  "text-sm font-medium transition-colors flex items-center gap-1 px-3 py-2 rounded-md",
                  location.pathname === link.path
                    ? "text-foreground bg-gold-gradient"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                {link.icon}
                {link.name}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-4">
                <Link to="/profile" className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg" alt={user.name} />
                    <AvatarFallback className="bg-gold-gradient text-white">
                      {user.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline text-sm font-medium">{user.name}</span>
                </Link>
                <Button 
                  variant="outline"
                  onClick={logout}
                  className="hidden md:flex"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link to="/login">
                  <Button variant="outline">Login</Button>
                </Link>
                <Link to="/signup">
                  <Button className="bg-gold-gradient hover:bg-gold-gradient-hover">Sign Up</Button>
                </Link>
              </div>
            )}

            {/* Mobile menu button */}
            <Button 
              variant="outline" 
              size="icon" 
              onClick={toggleMobileMenu} 
              className="md:hidden"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>
        </div>
      </header>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-background pt-16 animate-fade-in md:hidden">
          <nav className="container flex flex-col gap-4 p-4">
            {NavLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={cn(
                  "text-lg font-medium transition-colors flex items-center gap-3 px-4 py-3 rounded-md",
                  location.pathname === link.path
                    ? "text-foreground bg-gold-gradient"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.icon}
                {link.name}
              </Link>
            ))}
            {user && (
              <Button 
                variant="outline"
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
                className="mt-4"
              >
                Logout
              </Button>
            )}
          </nav>
        </div>
      )}
    </>
  );
}

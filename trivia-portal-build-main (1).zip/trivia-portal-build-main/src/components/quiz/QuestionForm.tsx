
import { useState } from 'react';
import { PlusCircle, Trash2 } from 'lucide-react';
import { Question } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

interface QuestionFormProps {
  question: Question;
  onChange: (question: Question) => void;
  onDelete: () => void;
}

export function QuestionForm({ question, onChange, onDelete }: QuestionFormProps) {
  const [newOption, setNewOption] = useState('');

  const handleQuestionTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange({ ...question, text: e.target.value });
  };

  const handleQuestionTypeChange = (type: Question['type']) => {
    onChange({ ...question, type, options: question.options || [], correctAnswers: [] });
  };

  const addOption = () => {
    if (!newOption.trim()) return;
    
    const updatedOptions = [...(question.options || []), newOption.trim()];
    onChange({ ...question, options: updatedOptions });
    setNewOption('');
  };

  const removeOption = (index: number) => {
    const updatedOptions = question.options?.filter((_, i) => i !== index) || [];
    const updatedCorrectAnswers = question.correctAnswers?.filter(
      answer => !question.options || question.options.indexOf(answer) !== index
    ) || [];
    
    onChange({ 
      ...question, 
      options: updatedOptions,
      correctAnswers: updatedCorrectAnswers 
    });
  };

  const handleCorrectAnswerChange = (option: string, isCorrect: boolean) => {
    let updatedCorrectAnswers = [...(question.correctAnswers || [])];
    
    if (question.type === 'multipleChoice') {
      updatedCorrectAnswers = isCorrect ? [option] : [];
    } else {
      if (isCorrect) {
        if (!updatedCorrectAnswers.includes(option)) {
          updatedCorrectAnswers.push(option);
        }
      } else {
        updatedCorrectAnswers = updatedCorrectAnswers.filter(answer => answer !== option);
      }
    }
    
    onChange({ ...question, correctAnswers: updatedCorrectAnswers });
  };

  return (
    <div className="space-y-6 border rounded-md p-6 bg-white/60 backdrop-blur-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Question</h3>
        <Button 
          onClick={onDelete}
          variant="outline"
          size="icon"
          className="h-8 w-8 text-destructive hover:bg-destructive/10"
        >
          <Trash2 size={16} />
        </Button>
      </div>
      
      <div className="space-y-4">
        <div>
          <Input
            value={question.text}
            onChange={handleQuestionTextChange}
            placeholder="Enter your question"
            className="bg-gold-gradient h-14 text-white placeholder:text-white/70"
          />
        </div>
        
        <div>
          <RadioGroup 
            value={question.type} 
            onValueChange={(value) => handleQuestionTypeChange(value as Question['type'])}
            className="grid grid-cols-3 gap-2"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="multipleChoice" id="multiple-choice" />
              <Label htmlFor="multiple-choice">Multiple Choice</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="checkboxes" id="checkboxes" />
              <Label htmlFor="checkboxes">Check Boxes</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="longAnswer" id="long-answer" />
              <Label htmlFor="long-answer">Long Answers</Label>
            </div>
          </RadioGroup>
        </div>
        
        {(question.type === 'multipleChoice' || question.type === 'checkboxes') && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Input
                value={newOption}
                onChange={(e) => setNewOption(e.target.value)}
                placeholder="Add an option"
                className="flex-1"
              />
              <Button
                onClick={addOption}
                type="button"
                size="sm"
                className="bg-quiz-primary hover:bg-quiz-secondary"
              >
                <PlusCircle size={16} className="mr-2" />
                Add
              </Button>
            </div>
            
            {question.options && question.options.length > 0 && (
              <div className="space-y-2">
                {question.options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2 py-2 px-4 rounded-md bg-muted">
                    {question.type === 'multipleChoice' ? (
                      <RadioGroup
                        value={question.correctAnswers?.includes(option) ? option : ''}
                        onValueChange={(value) => handleCorrectAnswerChange(option, !!value)}
                        className="flex items-center"
                      >
                        <RadioGroupItem value={option} id={`option-${index}`} />
                      </RadioGroup>
                    ) : (
                      <Checkbox
                        checked={question.correctAnswers?.includes(option) || false}
                        onCheckedChange={(checked) => handleCorrectAnswerChange(option, !!checked)}
                        id={`option-${index}`}
                      />
                    )}
                    <Label htmlFor={`option-${index}`} className="flex-1">
                      {option}
                    </Label>
                    <Button
                      onClick={() => removeOption(index)}
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        
        {question.type === 'longAnswer' && (
          <div>
            <Textarea
              disabled
              placeholder="Long answer input will be available to quiz takers"
              className="h-20 bg-muted/50"
            />
          </div>
        )}
      </div>
    </div>
  );
}

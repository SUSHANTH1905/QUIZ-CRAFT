
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Quiz } from '@/types';
import { User, Clock, Users, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

interface QuizCardProps {
  quiz: Quiz;
  showActions?: boolean;
}

export function QuizCard({ quiz, showActions = true }: QuizCardProps) {
  const formattedDate = new Date(quiz.createdAt).toLocaleDateString();
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const { toast } = useToast();
  
  const copyShareLink = () => {
    const shareUrl = `${window.location.origin}/play-quiz/${quiz.id}`;
    navigator.clipboard.writeText(shareUrl);
    
    toast({
      title: "Link Copied",
      description: "Share this link with friends to invite them to take this quiz!"
    });
    
    setShareDialogOpen(false);
  };
  
  return (
    <>
      <Card className="h-full transition-all hover:shadow-md overflow-hidden">
        <CardHeader className="bg-gold-gradient text-white p-4 flex flex-row gap-2 items-center">
          <div className="flex-1">
            <h3 className="text-lg font-semibold">{quiz.title}</h3>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-white/20 hover:bg-white/30">
              <Users size={14} className="mr-1" />
              {quiz.participants || 0}
            </Badge>
            
            <Button
              size="icon"
              variant="ghost"
              className="h-8 w-8 text-white hover:text-white/80 hover:bg-white/20"
              onClick={(e) => {
                e.preventDefault();
                setShareDialogOpen(true);
              }}
            >
              <Share2 size={16} />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-4 pt-6">
          <div className="flex flex-col gap-4">
            {quiz.description && (
              <p className="text-sm text-gray-600 line-clamp-2">{quiz.description}</p>
            )}
            
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock size={14} />
              <span>{formattedDate}</span>
            </div>
            
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <span>{quiz.questions.length} questions</span>
            </div>
            
            {showActions && (
              <div className="flex flex-wrap gap-2 mt-auto pt-2">
                <Link 
                  to={`/play-quiz/${quiz.id}`}
                  className="flex-1 text-center py-2 px-4 rounded-md bg-quiz-primary text-white text-sm hover:bg-quiz-secondary transition-colors"
                >
                  Start Quiz
                </Link>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Share Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share This Quiz</DialogTitle>
            <DialogDescription>
              Copy the link below to share this quiz with friends.
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center gap-2 mt-4">
            <Input 
              readOnly 
              value={`${window.location.origin}/play-quiz/${quiz.id}`} 
              onClick={(e) => (e.target as HTMLInputElement).select()}
            />
            <Button onClick={copyShareLink}>Copy</Button>
          </div>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setShareDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

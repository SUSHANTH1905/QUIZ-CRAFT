
-- Function to increment the participants count for a quiz
create or replace function increment_quiz_participants(quiz_id uuid)
returns void as $$
begin
  update quizzes
  set participants = participants + 1
  where id = quiz_id;
end;
$$ language plpgsql security definer;

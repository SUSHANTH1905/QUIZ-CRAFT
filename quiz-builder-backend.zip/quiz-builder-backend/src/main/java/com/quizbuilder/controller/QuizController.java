package com.quizbuilder.controller;

import com.quizbuilder.model.AppUser;
import com.quizbuilder.model.Quiz;
import com.quizbuilder.repository.AppUserRepository;
import com.quizbuilder.repository.QuizRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/quizzes")
public class QuizController {

    @Autowired
    private QuizRepository quizRepository;

    @Autowired
    private AppUserRepository userRepository;

    @PostMapping("/create")
    public ResponseEntity<?> createQuiz(@Valid @RequestBody Quiz quiz, BindingResult result,
                                        @RequestParam Long userId) {
        // Validate quiz data
        if (result.hasErrors()) {
            Map<String, String> errors = result.getFieldErrors().stream()
                    .collect(Collectors.toMap(
                            fieldError -> fieldError.getField(),
                            fieldError -> fieldError.getDefaultMessage(),
                            (existing, replacement) -> existing,
                            HashMap::new
                    ));
            return ResponseEntity.badRequest().body(errors);
        }

        // Find the user who is creating the quiz
        AppUser user = userRepository.findById(userId)
                .orElse(null);
        if (user == null) {
            Map<String, String> errors = new HashMap<>();
            errors.put("userId", "User not found with ID: " + userId);
            return ResponseEntity.badRequest().body(errors);
        }

        // Set the user as the creator of the quiz
        quiz.setCreatedBy(user);

        // Save the quiz
        Quiz savedQuiz = quizRepository.save(quiz);
        return ResponseEntity.ok(savedQuiz);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Quiz> getQuizById(@PathVariable Long id) {
        return quizRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Quiz>> getQuizzesByUserId(@PathVariable Long userId) {
        List<Quiz> quizzes = quizRepository.findByCreatedById(userId);
        return ResponseEntity.ok(quizzes);
    }
}
package com.quizbuilder.controller;

import com.quizbuilder.model.Question;
import com.quizbuilder.model.Quiz;
import com.quizbuilder.repository.QuestionRepository;
import com.quizbuilder.repository.QuizRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/questions")
public class QuestionController {

    @Autowired
    private QuestionRepository questionRepository;

    @Autowired
    private QuizRepository quizRepository;

    @PostMapping("/create")
    public ResponseEntity<?> createQuestion(@Valid @RequestBody Question question, BindingResult result,
                                            @RequestParam Long quizId) {
        // Validate question data
        if (result.hasErrors()) {
            Map<String, String> errors = result.getFieldErrors().stream()
                    .collect(Collectors.toMap(
                            fieldError -> fieldError.getField(),
                            fieldError -> fieldError.getDefaultMessage(),
                            (existing, replacement) -> existing,
                            HashMap::new
                    ));
            return ResponseEntity.badRequest().body(errors);
        }

        // Find the quiz to which this question belongs
        Quiz quiz = quizRepository.findById(quizId)
                .orElse(null);
        if (quiz == null) {
            Map<String, String> errors = new HashMap<>();
            errors.put("quizId", "Quiz not found with ID: " + quizId);
            return ResponseEntity.badRequest().body(errors);
        }

        // Validate that the correct answer is one of the options
        if (!question.getOptions().contains(question.getCorrectAnswer())) {
            Map<String, String> errors = new HashMap<>();
            errors.put("correctAnswer", "Correct answer must be one of the provided options");
            return ResponseEntity.badRequest().body(errors);
        }

        // Associate the question with the quiz
        question.setQuiz(quiz);

        // Save the question
        Question savedQuestion = questionRepository.save(question);
        return ResponseEntity.ok(savedQuestion);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Question> getQuestionById(@PathVariable Long id) {
        return questionRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/quiz/{quizId}")
    public ResponseEntity<List<Question>> getQuestionsByQuizId(@PathVariable Long quizId) {
        List<Question> questions = questionRepository.findByQuizId(quizId);
        return ResponseEntity.ok(questions);
    }
}
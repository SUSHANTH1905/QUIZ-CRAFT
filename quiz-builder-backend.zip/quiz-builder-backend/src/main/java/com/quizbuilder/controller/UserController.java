package com.quizbuilder.controller;

import com.quizbuilder.model.AppUser;
import com.quizbuilder.repository.AppUserRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private AppUserRepository userRepository;

    // 🟢 Signup endpoint
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@Valid @RequestBody AppUser user, BindingResult result) {
        if (result.hasErrors()) {
            Map<String, String> errors = result.getFieldErrors().stream()
                    .collect(Collectors.toMap(
                            fieldError -> fieldError.getField(),
                            fieldError -> fieldError.getDefaultMessage(),
                            (existing, replacement) -> existing,
                            HashMap::new
                    ));
            return ResponseEntity.badRequest().body(errors);
        }
        AppUser savedUser = userRepository.save(user);
        return ResponseEntity.ok(savedUser);
    }

    // 🟢 Get user by ID
    @GetMapping("/{id}")
    public ResponseEntity<AppUser> getUserById(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 🟢 Get all users
    @GetMapping
    public ResponseEntity<List<AppUser>> getAllUsers() {
        List<AppUser> users = userRepository.findAll();
        return ResponseEntity.ok(users);
    }

    // 🟢 Get user by username
    @GetMapping("/by-username")
    public ResponseEntity<AppUser> getUserByUsername(@RequestParam String username) {
        return userRepository.findByUsername(username)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // ✅ New: Login endpoint (username/email + password)
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> credentials) {
        String identifier = credentials.get("identifier");
        String password = credentials.get("password");

        Optional<AppUser> optionalUser = userRepository.findByUsername(identifier);
        if (optionalUser.isEmpty()) {
            optionalUser = userRepository.findByEmail(identifier);
        }

        Map<String, Object> response = new HashMap<>();

        if (optionalUser.isPresent() && optionalUser.get().getPassword().equals(password)) {
            AppUser user = optionalUser.get();
            response.put("success", true);
            response.put("userId", user.getId());
            return ResponseEntity.ok(response);
        } else {
            response.put("success", false);
            return ResponseEntity.status(401).body(response);
        }
    }
}
